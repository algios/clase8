# Contributors
Credit where credit is due

## Code Contributors

**Fabien Doiron**
* GitHub: [fabien-d](http://github.com/fabien-d)
* Twitter: [@fabien_doiron](http://twitter.com/fabien_doiron)
* Email: fabien.doiron@gmail.com

***

**Dan Panzarella**
* GitHub: [pzl](http://github.com/pzl)

***

**Antoine Corcy**
* GitHub: [toin0u](http://github.com/toin0u)
* Twitter: [@toin0u](https://twitter.com/toin0u)
* Email: contact@sbin.dk

***

**Stuart Keith**
* GitHub: [stuartkeith](http://github.com/stuartkeith)

***

**Dylan Anderson**
* GitHub: [quasipickle](http://github.com/quasipickle)

## Documentation Contributors

**Kristoffer Berdal**
* GitHub: [flexd](http://github.com/flexd)

***

**Michael Dabydeen**
* GitHub: [mdabydeen](http://github.com/mdabydeen)