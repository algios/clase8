<?php



class Clase2Controller extends BaseController{
  
  public  function getCss(){
    return View::make('index');
  }
 
}
